#ifndef PILHA_H_INCLUDED
#define PILHA_H_INCLUDED

typedef struct Nodo{
    int *info;
    int tam;
    struct Nodo *prox;
} nodo;

typedef struct {
    nodo *topo;
    int tamanho;
} Pilha;

Pilha *cria_pilha();
void pilha_push(Pilha *p, int *x, int tam, int *n_vetores);
int *pilha_pop(Pilha *p, int *tam_vetor, int *n_vetores);

#endif //PILHA_H_INCLUDED