#ifndef PILHA_H_INCLUDED
#define PILHA_H_INCLUDED
#define MAX 100

typedef struct {
    int *v[MAX];
    int tam[MAX];
    int topo; // posicao do topo da pilha, inicialmente -1
} Pilha;

Pilha *cria_pilha();
void pilha_push(Pilha *p, int *x, int tam, int *n_vetores);
int *pilha_pop(Pilha *p, int *tam_vetor, int *n_vetores);

#endif //PILHA_H_INCLUDED