#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "PD.h"
#define MAX 100

Pilha *cria_pilha() {
    Pilha *p = (Pilha *)malloc(sizeof(Pilha));
    p->topo = NULL;
    p->tamanho = 0;
    return p;
}

void pilha_push(Pilha *p, int *x, int tam, int *n_vetores) {
    nodo *novo;
    novo = (nodo*)malloc(sizeof(nodo));
    int i;
    novo->info = x;
    novo->tam = tam;
    novo->prox = p->topo;
    p->topo = novo;
    *n_vetores = *n_vetores + 1;
}

int *pilha_pop(Pilha *p, int *tam_vetor, int *n_vetores) {
    if(p->topo == NULL){
        printf("Pilha vazia.");
        return NULL;
    }
    *n_vetores = *n_vetores - 1;
    int *ptr;
    *tam_vetor = p->topo->tam;
    ptr = p->topo->info;
    nodo *aux = p->topo->prox; // e se estiver vazia?
    free(p->topo);
    p->topo = aux;
    return ptr;
}