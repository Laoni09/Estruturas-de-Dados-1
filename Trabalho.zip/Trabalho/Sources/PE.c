#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "PE.h"
#define MAX 100

Pilha *cria_pilha() {
    Pilha *p = (Pilha *)malloc(sizeof(Pilha));
    p->topo = -1;
    return p;
}

void pilha_push(Pilha *p, int *x, int tam, int *n_vetores) {
    p->topo++;
    *n_vetores = p->topo + 1;
    p->v[p->topo] = x;
    p->tam[p->topo] = tam;
    // e se estiver cheia?
}

int *pilha_pop(Pilha *p, int *tam_vetor, int *n_vetores) {
    if(p->topo == -1){
        printf("Pilha vazia.");
        return 0;
    }
    int *ptr;
    ptr = p->v[p->topo];
    *tam_vetor = p->tam[p->topo];
    p->topo--;
    *n_vetores = p->topo + 1;
    return ptr;
}
