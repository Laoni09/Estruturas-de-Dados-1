#include <stdio.h>
#include <stdlib.h>
#include "FD.h"

Fila *cria_fila() {
    Fila *f = (Fila *)malloc(sizeof(Fila));
    f->ini = f->fim = NULL;
}

void fila_push(Fila *f, int x) { // e se estiver cheia?
    nodo *novo = (nodo *)malloc(sizeof(nodo));
    novo->info = x;
    novo->prox = NULL;
    if (f->fim != NULL) // Por que este if ´e importante?
    f->fim->prox = novo;
    f->fim = novo;
    if (f->ini==NULL) // E este?
    f->ini = novo;
}

int fila_pop(Fila *f) { // e se estiver vazia?
    int x = f->ini->info;
    nodo *aux = f->ini->prox;
    if (f->fim == f->ini) // Por que este if ´e importante?
    f->fim = NULL;
    free(f->ini);
    f->ini = aux;
    return x;
}