#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "PD.h"
#include "FE.h"

void bucketSort(int *v, int n, int exp){
    int count[10];
    int i, j = 0, k = 0;

    Fila *buckets[10];
    for(i = 0; i < 10; i++){
        buckets[i] = cria_fila();
        count[i] = 0;
    }

    for(i = 0; i < n; i++){
        fila_push(buckets[(v[i]%(10*exp))/exp], v[i]);
        count[(v[i]%(10*exp))/exp]++;
    }

    for(i = 0; i < 10; i++){
        for(j = 0; j < count[i]; j++){
            v[k] = fila_pop(buckets[i]);
            k++;
        }
    }
}

void radixSort(int *v, int n, int ndigitos){
    int i, j, exp = 1;
    for(i = 0; i < ndigitos; i++){
        bucketSort(v, n, exp);
        exp *= 10;
        printf("[");
        for(j = 0; j < n; j++){
            printf("%d ", v[j]);
        }
        printf(".\n");
    }
}

int contaDigitos(int x){
    int i = 0;
    while (x != 0)
    {
        x /= 10;
        i++;
    }
    return i;
}

int main(){
    Pilha *p = cria_pilha();
    int tam_vetor, n_vetores = 0, n_digitos = 0, cond = 0;
    char condstr[20];
    int vetor[MAX];
    int *ptr;
    do {
        //trata as condições
        scanf("%s", &condstr);
        if(strcmp(condstr, "push") == 0) cond = 1;
        if(strcmp(condstr, "pop") == 0) cond = 2;
        else if(strcmp(condstr, "F") == 0) cond = 3;
        int x[MAX], *xptr, num = 0, i = 0, j;
        switch (cond)
        {
        case 1:
            while (1)
            {
                scanf("%d", &num);
                if(num == -1) break;
                x[i] = num;
                printf("%d ", x[i]);
                i++;
            }
            xptr = (int*)malloc(sizeof(int)*i);
            for(j = 0; j < i; j++){
                xptr[j] = x[j];
            }
            pilha_push(p, xptr, i, &n_vetores);
            printf("\n");
            break;
        case 2:
            //arrumar depois
            ptr = pilha_pop(p, &tam_vetor, &n_vetores);
            for (i = 0; i < tam_vetor; i++)
            {
                vetor[i] = ptr[i];
                printf("%d ", ptr[i]);
            }
            printf("\n");
            n_digitos = contaDigitos(vetor[0]);
            radixSort(vetor, tam_vetor, n_digitos);
            break;
        case 3:
            printf("%d vetores sem ordenar.", n_vetores);
            cond = -1;
            break;
        }

    } while(cond != -1);
    free(ptr);
}
